#!/usr/bin/env python3
"""Gera os SVGs do README de perfil. Edite a seção CONFIG e rode:  python3 generate.py"""
import random
from html import escape
from pathlib import Path
from icons_data import ICONS

# ======================= CONFIG (edite aqui) =======================
BANNER_LINES = ["Better systems.", "Fewer vulnerabilities.", "A safer tomorrow."]
BANNER_SIDE = ["Small steps.", "Big results."]
BANNER_KANJI = "継続は力なり"

STATS = [("repo", "46", "Total Repositories"), ("commit", "1.2k", "Commits"),
         ("pr", "24", "Pull Requests"), ("issue", "12", "Issues")]

LANGS = [("Python", 42.7, "#3b82f6"), ("TypeScript", 18.3, "#1d6fe8"),
         ("JavaScript", 12.6, "#facc15"), ("Shell", 8.1, "#4ade80"), ("Other", 18.3, "#a5b4fc")]

CURRENTLY = ["Learning new things", "Automating the boring stuff", "Exploring the cloud",
             "Playing around with tools", "Building cool projects",
             "Trying to be a little better|than yesterday"]   # '|' = quebra de linha

HIGHLIGHTS = [("shield", "Veracode", ["AppSec & SAST/SCA"]), ("cicd", "CI/CD", ["Build · Test · Deploy"]),
              ("cloud", "Cloud", ["Scalable & Secure"]),
              ("brain", "Problem Solving", ["Turning ideas into", "working solutions"])]

FUN = [("ball", "Football", ["Good game,", "better mood."]), ("gym", "Gym", ["Discipline", "builds freedom."]),
       ("coffee", "Coffee", ["Fuel for", "big ideas."]), ("music", "Music", ["Always", "in the playlist."]),
       ("travel", "Travel", ["New places,", "same curiosity."])]

ART_TEXT = ["Good", "Things", "Take", "Time"]
# ===================================================================

MONO = "'JetBrains Mono','Fira Code','SF Mono',Consolas,'DejaVu Sans Mono',monospace"
JP = "'Noto Sans JP','Hiragino Sans','Yu Gothic','Meiryo',sans-serif"
HAND = "'Segoe Script','Brush Script MT','Lucida Handwriting','Snell Roundhand',cursive"
BG, CARD, EDGE, BLUE, LIGHT, SOFT = "#02061a", "#030816", "#1a3a9e", "#4f8cff", "#d6e4ff", "#6ea0ff"
NS = 'xmlns="http://www.w3.org/2000/svg"'


def T(x, y, s, size=16, fill=LIGHT, weight=400, anchor="start", family=MONO, extra=""):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" font-weight="{weight}" '
            f'fill="{fill}" text-anchor="{anchor}" {extra}>{escape(s)}</text>')


def card(x, y, w, h, stroke=EDGE, fill=CARD, rx=14, sw=1.6):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'


def simple(name, x, y, size, fill):
    return f'<g transform="translate({x} {y}) scale({size/24})"><path d="{ICONS[name]}" fill="{fill}"/></g>'


# ---- ícones de traço (grade 24x24) ----
STROKE = {
    "repo": '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
    "commit": '<circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="2.5"/><path d="M12 1.5v4M12 18.5v4M1.5 12h4M18.5 12h4"/>',
    "pr": '<circle cx="6" cy="5.5" r="2.3"/><circle cx="6" cy="18.5" r="2.3"/><circle cx="18" cy="18.5" r="2.3"/><path d="M6 8v8M18 16V9a3 3 0 0 0-3-3h-3M14 3.5 11.5 6 14 8.5"/>',
    "issue": '<circle cx="12" cy="12" r="9"/><path d="M12 6.5V12l3.5 2.5"/>',
    "code": '<path d="M8 6l-6 6 6 6M16 6l6 6-6 6M14 4l-4 16"/>',
    "term": '<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M7 9l3 3-3 3M12.5 15H17"/>',
    "shield": '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    "cicd": '<circle cx="7" cy="5.5" r="2.5"/><circle cx="17" cy="18.5" r="2.5"/><path d="M7 8v3a4 4 0 0 0 4 4h3.5M17 16v-3a4 4 0 0 0-4-4H9.5"/>',
    "cloud": '<path d="M7 18a4 4 0 0 1-.5-7.9A6 6 0 0 1 18 9.5a4.3 4.3 0 0 1-.5 8.5z"/>',
    "brain": '<path d="M12 5C10 3 6 4 6 8c-2 1-2 5 .5 6-.5 3 2.5 5.5 5.5 4M12 5c2-2 6-1 6 3 2 1 2 5-.5 6 .5 3-2.5 5.5-5.5 4M12 5v13M9 10h3M15 10h-3M9 14h3M15 14h-3"/>',
    "gamepad": '<path d="M7 8h10a4 4 0 0 1 4 4v1a3 3 0 0 1-5.2 2L14.5 14h-5L8.2 15A3 3 0 0 1 3 13v-1a4 4 0 0 1 4-4z"/><path d="M8 10.5v3M6.5 12h3"/><circle cx="15.5" cy="11" r=".8"/><circle cx="17.5" cy="13" r=".8"/>',
    "gym": '<path d="M2 9.5v5M5 7v10M19 7v10M22 9.5v5M5 12h14"/>',
    "coffee": '<path d="M5 9h12v5a5 5 0 0 1-5 5h-2a5 5 0 0 1-5-5zM17 11h1.5a2.5 2.5 0 0 1 0 5H17M3.5 21.5h15M8 3.5c0 1.5 1.5 1.5 1.5 3M12 3.5c0 1.5 1.5 1.5 1.5 3"/>',
    "music": '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    "travel": '<path d="M2 20 9.5 7l4 7 2.5-4L22 20z"/><path d="m7.5 10.5 2 1.5 1.5-1.5"/>',
    "arrow": '<path d="M4 12h15M13 6l6 6-6 6"/>',
    "chev": '<path d="M8 4l8 8-8 8"/>',
}


def ico(name, x, y, size, color=BLUE, sw=1.8):
    return (f'<g transform="translate({x} {y}) scale({size/24})" fill="none" stroke="{color}" '
            f'stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{STROKE[name]}</g>')


def ball(x, y, size):
    s = size / 24
    return (f'<g transform="translate({x} {y}) scale({s})"><circle cx="12" cy="12" r="11" fill="#e8f0ff"/>'
            '<polygon points="12,7.2 16.3,10.3 14.7,15.4 9.3,15.4 7.7,10.3" fill="#050d26"/>'
            '<path d="M12 7.2V2M16.3 10.3l5-1.6M14.7 15.4l3 4.2M9.3 15.4l-3 4.2M7.7 10.3l-5-1.6" stroke="#050d26" stroke-width="1.4" fill="none"/></g>')


def svg(w, h, inner, defs=""):
    return (f'<svg {NS} viewBox="0 0 {w} {h}" width="{w}" height="{h}" role="img">'
            f'<defs>{defs}</defs>{inner}</svg>')


# ============================ BANNER ============================
def banner():
    W, H = 1482, 190
    rnd = random.Random(7)
    defs = f'''
<clipPath id="c"><rect x="1" y="1" width="{W-2}" height="{H-2}" rx="14"/></clipPath>
<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#02061f"/><stop offset=".6" stop-color="#0a1a63"/><stop offset="1" stop-color="#1536b8"/></linearGradient>
<radialGradient id="glow"><stop offset="0" stop-color="#6f95ff" stop-opacity=".75"/><stop offset=".45" stop-color="#2a4fe0" stop-opacity=".35"/><stop offset="1" stop-color="#1536b8" stop-opacity="0"/></radialGradient>
<radialGradient id="moon" cx=".4" cy=".35"><stop offset="0" stop-color="#f2f6ff"/><stop offset="1" stop-color="#9db8ff"/></radialGradient>
<linearGradient id="fadeL" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="{CARD}"/><stop offset=".3" stop-color="{CARD}" stop-opacity=".96"/><stop offset=".47" stop-color="{CARD}" stop-opacity="0"/></linearGradient>
<linearGradient id="fadeR" x1="0" y1="0" x2="1" y2="0"><stop offset=".78" stop-color="{CARD}" stop-opacity="0"/><stop offset=".9" stop-color="{CARD}" stop-opacity=".95"/></linearGradient>
<linearGradient id="water" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d2a9a"/><stop offset="1" stop-color="#030a2c"/></linearGradient>'''
    s = [f'<g clip-path="url(#c)"><rect width="{W}" height="{H}" fill="url(#sky)"/>']
    for _ in range(70):
        s.append(f'<circle cx="{rnd.randint(470,1250)}" cy="{rnd.randint(6,120)}" r="{rnd.choice([.6,.8,1.1])}" fill="#bcd0ff" opacity="{rnd.choice([.4,.6,.9])}"/>')
    s.append('<circle cx="947" cy="68" r="150" fill="url(#glow)"/><circle cx="947" cy="68" r="72" fill="url(#moon)"/>')
    s.append('<circle cx="925" cy="52" r="9" fill="#8aa6ec" opacity=".35"/><circle cx="962" cy="78" r="12" fill="#8aa6ec" opacity=".3"/><circle cx="935" cy="88" r="6" fill="#8aa6ec" opacity=".3"/>')
    s.append('<path d="M280 157Q420 126 560 157Z" fill="#07164f" opacity=".9"/><path d="M1140 157Q1280 128 1420 157Z" fill="#07164f" opacity=".9"/>')
    s.append('<path d="M520 160L700 150 800 128 880 104 930 80H962L1012 104 1090 130 1160 150 1210 160Z" fill="#1236b0"/>')
    s.append('<path d="M912 100 930 80H962L982 100 970 105 958 94 945 107 931 95 920 105Z" fill="#a9c2ff" opacity=".9"/>')
    s.append('<path d="M360 157Q520 140 700 157T1050 160 1482 157V190H360Z" fill="#030a2c"/>')
    s.append(f'<rect x="300" y="157" width="{W-300}" height="{H-157}" fill="url(#water)" opacity=".85"/>')
    s.append('<path d="M360 157Q520 143 700 157T1050 158 1400 157" fill="none" stroke="#4f78ff" stroke-width="1.5" opacity=".7"/>')
    for i, (w, o) in enumerate([(150, .55), (110, .4), (80, .3), (50, .25)]):
        s.append(f'<rect x="{947-w/2}" y="{163+i*8}" width="{w}" height="2.2" rx="1" fill="#b4c8ff" opacity="{o}"/>')
    # torii
    s.append('<g fill="#02081f" stroke="#3358e0" stroke-width=".6"><rect x="1029" y="94" width="7" height="66"/><rect x="1068" y="94" width="7" height="66"/>'
             '<path d="M1012 84Q1052 94 1092 84L1090 93Q1052 101 1014 93Z"/><rect x="1024" y="102" width="56" height="5"/><rect x="1048" y="94" width="8" height="9"/></g>')
    s.append(f'<rect width="{W}" height="{H}" fill="url(#fadeL)"/><rect width="{W}" height="{H}" fill="url(#fadeR)"/></g>')
    for i, line in enumerate(BANNER_LINES):
        s.append(T(49, 56 + i * 28.5, "> " + line, 19.5, "#5aa9ff"))
    s.append(f'<rect x="49" y="143" width="21" height="4" fill="#cfe0ff"><animate attributeName="opacity" values="1;1;0;0;1" dur="1.2s" repeatCount="indefinite"/></rect>')
    for i, ch in enumerate(BANNER_KANJI):
        s.append(T(1291, 42 + i * 22, ch, 21, LIGHT, 500, "middle", JP))
    for i, line in enumerate(BANNER_SIDE):
        s.append(T(1338, 136 + i * 20, line, 13.5, "#a9c4ff"))
    s.append(f'<rect x="1" y="1" width="{W-2}" height="{H-2}" rx="14" fill="none" stroke="#1d4ed8" stroke-width="2"/>')
    return svg(W, H, "".join(s), defs)


# ============================ BADGES ============================
def badges():
    W, H = 1482, 54
    chips = [("Veracode", 1, 159), ("GitLab", 177, 136), ("GitHub", 329, 138), ("Docker", 484, 137),
             ("Kubernetes", 637, 169), ("Python", 823, 136), ("Linux", 976, 126), ("AWS", 1119, 126)]
    defs = ('<linearGradient id="vc" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22b8ee"/><stop offset="1" stop-color="#1450d8"/></linearGradient>'
            '<linearGradient id="py" x1="0" y1="0" x2="1" y2="1"><stop offset=".5" stop-color="#3b82c4"/><stop offset=".5" stop-color="#ffd43b"/></linearGradient>'
            '<linearGradient id="tux" x1="0" y1="0" x2="0" y2="1"><stop offset=".78" stop-color="#f1f5ff"/><stop offset=".78" stop-color="#f6c744"/></linearGradient>')
    s = []
    for name, x, w in chips:
        s.append(f'<rect x="{x}" y="1" width="{w}" height="52" rx="10" fill="#06102a" stroke="#1d4ed8" stroke-width="1.6"/>')
        ix, iy = x + 19, 12
        if name == "Veracode":
            s.append(f'<g transform="translate({ix} {iy})"><path d="M0 3H9.5L15 19 20.5 3H30L19 29H11Z" fill="url(#vc)" transform="scale(.93)"/></g>')
        elif name == "GitLab":
            s.append(simple("gitlab", ix, iy, 29, "#fc6d26"))
        elif name == "GitHub":
            s.append(f'<circle cx="{ix+15}" cy="27" r="16" fill="#f4f7ff"/>' + simple("github", ix - 1, iy - 3, 32, "#02061a"))
        elif name == "Docker":
            s.append(simple("docker", ix - 2, iy, 34, "#2496ed"))
        elif name == "Kubernetes":
            s.append(simple("kubernetes", ix - 1, iy - 2, 32, "#326ce5"))
        elif name == "Python":
            s.append(simple("python", ix, iy, 29, "url(#py)"))
        elif name == "Linux":
            s.append(simple("linux", ix, iy - 1, 31, "url(#tux)"))
        elif name == "AWS":
            s.append(T(ix - 1, 29, "aws", 19, "#ffffff", 700, family="Arial,Helvetica,sans-serif") +
                     f'<path d="M{ix-1} 35Q{ix+16} 44 {ix+34} 33" fill="none" stroke="#ff9900" stroke-width="2.6" stroke-linecap="round"/>'
                     f'<path d="M{ix+29} 31.5l5.5 1.2-2 5" fill="none" stroke="#ff9900" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>')
        tx = x + (76 if name == "AWS" else 62)
        s.append(T(tx, 32, name, 17.5, LIGHT, 500))
    return svg(W, H, "".join(s), defs)


# ============================ DASHBOARD ============================
def dashboard():
    W, H = 1482, 697
    rnd = random.Random(42)
    defs = '''
<linearGradient id="art" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#050a2b"/><stop offset=".5" stop-color="#101a66"/><stop offset=".78" stop-color="#3a22a0"/><stop offset="1" stop-color="#7a2bb8"/></linearGradient>
<linearGradient id="hz" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ec4899" stop-opacity="0"/><stop offset="1" stop-color="#7c3aed" stop-opacity=".55"/></linearGradient>
<radialGradient id="lap"><stop offset="0" stop-color="#60a5fa" stop-opacity=".8"/><stop offset="1" stop-color="#60a5fa" stop-opacity="0"/></radialGradient>
<clipPath id="artc"><rect x="1135" y="662" width="374" height="333" rx="14"/></clipPath>'''
    s = [f'<rect width="{W}" height="{H}" fill="{BG}"/><g transform="translate(-28 -298)">']

    # ---------- GitHub Stats ----------
    s.append(card(29, 299, 673, 274))
    s.append(simple("github", 48, 320, 32, "#e8f0ff") + T(95, 340, "GitHub Stats", 22, LIGHT, 500, extra='letter-spacing="1"'))
    for i, (ic, val, lab) in enumerate(STATS):
        y = 381 + i * 48.5
        s.append(ico(ic, 52, y - 14, 26, BLUE, 2) + T(97, y + 5, val, 25, "#f1f6ff", 500) + T(97, y + 24, lab, 14, SOFT))
    s.append(T(285, 382, "Contributions in the last year", 14, SOFT))
    pal = ["#0c1a48", "#12307f", "#1d4ed8", "#3b82f6", "#60a5fa", "#a5c8ff"]
    wts = [.14, .34, .22, .16, .1, .04]
    for c in range(23):
        for r in range(7):
            lv = rnd.choices(range(6), wts)[0]
            s.append(f'<rect x="{287+c*16.9:.1f}" y="{401+r*15.1:.1f}" width="12.5" height="11.5" rx="2" fill="{pal[lv]}"/>')
    for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()):
        s.append(T(287 + i * 33.4, 537, m, 12.5, SOFT))

    # ---------- Top Languages ----------
    s.append(card(717, 299, 398, 274))
    s.append(ico("code", 735, 322, 26, BLUE, 2) + T(773, 341, "Top Languages", 22, LIGHT, 500, extra='letter-spacing="1"'))
    for i, (name, pct, col) in enumerate(LANGS):
        y = 386 + i * 36.4
        w = 144 * min(1, 0.12 + pct * 0.0162)
        s.append(f'<circle cx="750" cy="{y}" r="10" fill="{col}"/>' + T(772, y + 6, name, 16.5, LIGHT)
                 + f'<rect x="887" y="{y-7}" width="144" height="14" rx="7" fill="#14213f"/><rect x="887" y="{y-7}" width="{w:.1f}" height="14" rx="7" fill="{col}"/>'
                 + T(1090, y + 6, f"{pct:.1f}%", 16, LIGHT, anchor="end"))

    # ---------- Currently ----------
    s.append(card(1135, 299, 374, 351))
    s.append(ico("term", 1165, 322, 28, BLUE, 2) + T(1211, 342, "Currently", 22, LIGHT, 500, extra='letter-spacing="1"'))
    y = 381
    for line in CURRENTLY:
        parts = line.split("|")
        s.append(ico("chev", 1166, y - 12, 15, BLUE, 2.4))
        for j, p in enumerate(parts):
            s.append(T(1197, y + j * 22.5, p, 16.5, LIGHT))
        y += 28.4 + 22.5 * (len(parts) - 1)
    s.append(f'<path d="M1157 573H1487" stroke="#1c2b57" stroke-width="1.5"/>')
    s.append(T(1167, 623, "( •_• )", 30, "#c9dcff", 400))

    # ---------- Arte ----------
    s.append('<g clip-path="url(#artc)"><rect x="1135" y="662" width="374" height="333" fill="url(#art)"/>')
    for _ in range(90):
        s.append(f'<circle cx="{rnd.randint(1138,1506)}" cy="{rnd.randint(664,880)}" r="{rnd.choice([.6,.9,1.2,1.6])}" fill="#cfdcff" opacity="{rnd.choice([.3,.5,.9])}"/>')
    s.append('<path d="M1135 905 1210 880 1290 895 1370 872 1460 890 1509 880V960H1135Z" fill="#0a1148"/>')
    x = 1140
    while x < 1509:
        bw, bh = rnd.randint(7, 15), rnd.randint(14, 62)
        s.append(f'<rect x="{x}" y="{958-bh}" width="{bw}" height="{bh}" fill="{rnd.choice(["#0b1a63","#0a1450","#12206f"])}"/>')
        for wy in range(958 - bh + 4, 954, 6):
            for wx in range(x + 2, x + bw - 2, 4):
                if rnd.random() < .38:
                    s.append(f'<rect x="{wx}" y="{wy}" width="1.8" height="2.6" fill="{rnd.choice(["#60a5fa","#f472b6","#fcd34d","#93c5fd"])}" opacity=".9"/>')
        x += bw + rnd.randint(0, 2)
    s.append('<path d="M1444 958V838M1444 838l-3-14M1444 838l3-14" stroke="#1a2a85" stroke-width="3"/><circle cx="1444" cy="900" r="5" fill="#0d1a60"/>'
             '<rect x="1135" y="900" width="374" height="70" fill="url(#hz)"/>')
    s.append('<path d="M1135 995V972L1230 950 1290 916 1345 906 1420 916 1509 942V995Z" fill="#02030f"/>')
    s.append('<ellipse cx="1360" cy="880" rx="46" ry="26" fill="url(#lap)"/>'
             '<path d="M1307 872Q1304 892 1316 906L1346 906 1346 868Z" fill="#0e1544"/>'
             '<path d="M1318 868Q1322 858 1334 860L1346 868 1344 906 1318 906Z" fill="#050818" stroke="#2f5be0" stroke-width=".8"/>'
            '<circle cx="1334" cy="848" r="13" fill="#050818" stroke="#3b6cf0" stroke-width=".9"/>'
             '<path d="M1342 884L1372 880 1384 900 1346 906Z" fill="#050818" stroke="#2f5be0" stroke-width=".7"/>'
             '<path d="M1362 862L1386 868 1384 888 1360 884Z" fill="#2563eb" stroke="#93c5fd" stroke-width="1"/>'
             '<path d="M1358 886L1386 890 1390 894 1356 890Z" fill="#0b1b66"/></g>')
    for i, word in enumerate(ART_TEXT):
        px, py = 1158 + [0, 5, 14, 5][i % 4], 724 + i * 35
        s.append(T(px, py, word, 39, "#2f6bff", 400, family=HAND, extra=f'font-style="italic" transform="rotate(-12 {px} {py})"'))
    s.append('<path d="M1160 842Q1195 834 1228 828" stroke="#2f6bff" stroke-width="3" fill="none" stroke-linecap="round"/>')
    s.append(f'<rect x="1135" y="662" width="374" height="333" rx="14" fill="none" stroke="{EDGE}" stroke-width="1.6"/>')

    # ---------- Recent Highlights ----------
    s.append(card(29, 596, 1086, 221))
    s.append('<path d="M63 614l4.2 8.6 9.5 1.4-6.9 6.7 1.6 9.4-8.4-4.5-8.5 4.5 1.7-9.4-6.9-6.7 9.5-1.4z" fill="#4f8cff" transform="translate(0 -4)"/>')
    s.append(T(95, 634, "Recent Highlights", 22, LIGHT, 500, extra='letter-spacing="1"'))
    for (x0, w), (ic, title, sub) in zip([(52, 253), (322, 247), (585, 247), (849, 242)], HIGHLIGHTS):
        small = len(sub) > 1
        s.append(card(x0, 657, w, 141, "#1e40af", "#050d26", 8, 1.4))
        s.append(ico(ic, x0 + 24, 674, 32, BLUE, 1.9))
        s.append(T(x0 + 27, 725, title, 15.5 if small else 17.5, "#e8f0ff", 500))
        for j, ln in enumerate(sub):
            s.append(T(x0 + 27, 749 + j * 18, ln, 13.5 if small else 14.5, SOFT))
        s.append(ico("arrow", x0 + 26, 770 + (6 if small else 0), 14, "#e8f0ff", 2.2))

    # ---------- Fun Facts ----------
    s.append(card(29, 838, 1086, 151))
    s.append(ico("gamepad", 52, 852, 34, BLUE, 1.9) + T(99, 873, "Fun Facts", 22, LIGHT, 500, extra='letter-spacing="1"'))
    for xd in (247, 481, 695, 906):
        s.append(f'<path d="M{xd} 892V964" stroke="#1a3170" stroke-width="1.4"/>')
    for (ic, title, sub), (xi, xt) in zip(FUN, [(66, 113), (285, 336), (522, 568), (730, 775), (945, 993)]):
        s.append((ball(xi, 898, 31) if ic == "ball" else ico(ic, xi, 897, 34, BLUE, 1.7)))
        s.append(T(xt, 914, title, 16.5, "#e8f0ff", 500))
        for j, ln in enumerate(sub):
            s.append(T(xt, 938 + j * 20, ln, 13.5, SOFT))
    s.append('</g>')
    return svg(W, H, "".join(s), defs)


if __name__ == "__main__":
    out = Path(__file__).parent / "assets"
    out.mkdir(exist_ok=True)
    for name, fn in [("banner", banner), ("badges", badges), ("dashboard", dashboard)]:
        (out / f"{name}.svg").write_text(fn(), encoding="utf-8")
        print("gerado:", out / f"{name}.svg")
