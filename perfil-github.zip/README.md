<div align="center">

<img src="assets/banner.svg" width="100%" alt="Better systems. Fewer vulnerabilities. A safer tomorrow." />
<img src="assets/badges.svg" width="100%" alt="Veracode, GitLab, GitHub, Docker, Kubernetes, Python, Linux, AWS" />
<img src="assets/dashboard.svg" width="100%" alt="GitHub Stats, Top Languages, Currently, Recent Highlights e Fun Facts" />

</div>
